using UnityEngine;

public class Enemy : MonoBehaviour
{
    public Minotaur minotaur;

    public Movement movement { get; private set; }
    public EnemyChase chase { get; private set; }
    public EnemyFrightened frightened { get; private set; }
    public EnemyHome home { get; private set; }
    public EnemyScatter scatter { get; private set; }

    public EnemyBehavior initialbehavior;
    public Transform initialtarget;
    public Transform target;

    public virtual int difficultyrating { get; private set; }

    public Lever lever;

    public virtual int points { get; private set; }
    public GateSpawn spawnLocation;

    private void Awake()
    {
        this.movement = GetComponent<Movement>();
        this.scatter = GetComponent<EnemyScatter>();
        this.chase = GetComponent<EnemyChase>();
        this.frightened = GetComponent<EnemyFrightened>();

        this.minotaur = FindObjectOfType<Minotaur>();
    }

    public void EnemyHit()
    {
        EnemyKilled();
    }

    public void EnemyKilled()
    {
        FindObjectOfType<GameManagerScript>().IncreaseScore(points);
        Killed();
    }

    public void Killed()
    {
        Destroy(gameObject);
    }

    private void Update()
    {
        RaycastHit2D hit = Physics2D.BoxCast(this.transform.position, Vector2.one * .8f, 0.0f, this.movement.direction, .9f, this.movement.wallLayer);
        

    }
}