using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyScatter : EnemyBehavior
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Node node = collision.GetComponent<Node>();

        if (node != null && this.enabled && !this.enemy.frightened.enabled)
        {
            int index = Random.Range(0, node.directions.Count);

            if (node.directions[index] == -this.enemy.movement.direction)
            {
                index++;

                if (index >= node.directions.Count)
                {
                    index = 0;
                }
            }

            this.enemy.movement.SetDirection(node.directions[index]);
        }
    }
}

