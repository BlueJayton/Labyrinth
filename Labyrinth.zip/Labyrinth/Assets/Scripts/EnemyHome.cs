using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHome : EnemyBehavior
{
    public void OnEnable()
    {
        this.enemy.target = this.enemy.spawnLocation.transform;
    }

    public void OnDisable()
    {
        this.enemy.initialbehavior.Enable();
    }
}
