using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lerp : MonoBehaviour
{
    public Vector3 startPosition;
    public Vector3 endPosition;
    public float duration = 3;
    private float elapsedTime = 0;

    void Start()
    {
        startPosition = transform.position;

        this.enabled = false;
    }

    void Update()
    {

        elapsedTime += Time.deltaTime;


        float t = Mathf.Clamp01(elapsedTime / duration);


        Vector3 newPos = Vector3.Lerp(startPosition, endPosition, t);
        newPos.y = transform.position.y; 
        transform.position = newPos;

        if (t == 1)
        {
            enabled = false;
        }
    }

    public void Enable()
    {
        elapsedTime = 0;
        enabled = true;
    }
}