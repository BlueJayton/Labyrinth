using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class Movement : MonoBehaviour
{
    public float speed = 8.0f;
    public float speedMultiplier = 1.0f;
    public Vector2 initialDirection;
    public LayerMask wallLayer;

    public Rigidbody2D rigidBody { get; private set; }
    public Vector2 direction;
    public Vector2 nextDirection { get; private set; }
    public Vector3 startingPosition { get; private set; }

    private void Awake()
    {
        this.rigidBody = GetComponent<Rigidbody2D>();
        this.startingPosition = this.transform.position;
    }

    private void Start()
    {
        ResetState();
    }

    private void Update()
    {
        if (this.nextDirection != Vector2.zero)
        {
            SetDirection(this.nextDirection);
        }
    }

    public void ResetState()
    {
        this.speedMultiplier = 1.0f;
        this.direction = this.initialDirection;
        this.nextDirection = Vector2.zero;
        this.transform.position = this.startingPosition;
        this.rigidBody.isKinematic = false;
        this.enabled = true;
    }

    private void FixedUpdate()
    {
        Vector2 position = this.rigidBody.position;
        Vector2 translation = this.direction * this.speed * this.speedMultiplier * Time.fixedDeltaTime;
        this.rigidBody.MovePosition(position + translation);

        if (this.direction == Vector2.right) // 1X 0Y direction
        {
            Quaternion newRotation = Quaternion.Euler(0f, 0f, -90f);
            this.transform.rotation = newRotation;
        }
        else if (this.direction == Vector2.left)
        {
            Quaternion newRotation = Quaternion.Euler(0f, 0f, 90f);
            this.transform.rotation = newRotation;
        }
        else if (this.direction == Vector2.up)
        {
            Quaternion newRotation = Quaternion.Euler(0f, 0f, 0f);
            this.transform.rotation = newRotation;
        }
        else if (this.direction == Vector2.down)
        {
            Quaternion newRotation = Quaternion.Euler(0f, 0f, 180f);
            this.transform.rotation = newRotation;
        }

    }

    public void SetDirection (Vector2 direction, bool forced = false)
    {
        if (forced || !isOccupied(direction))
        {
            this.direction = direction;
            this.nextDirection = Vector2.zero;
        }
        else
        {
            this.nextDirection = direction;
        }
    }

    public bool isOccupied(Vector2 direction)
    {
        RaycastHit2D hit = Physics2D.BoxCast(this.transform.position, Vector2.one * .8f, 0.0f, direction, .9f, this.wallLayer);
        return hit.collider != null;
    }

    public void Stun(float duration)
    {
        this.enabled = false;
        this.rigidBody.velocity = Vector2.zero;
        this.speedMultiplier = 0f;
        Invoke("ResetSpeedMultiplier", duration);
    }

    private void ResetSpeedMultiplier()
    {
        this.enabled = true;
        this.speedMultiplier = 1.0f;
    }
}
