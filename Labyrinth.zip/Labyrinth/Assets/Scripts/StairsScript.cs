using UnityEngine;

public class StairsScript : MonoBehaviour
{
    public Transform connection;
    public Vector2 direction;

    private void OnTriggerEnter2D(Collider2D other)
    {

        Vector3 posistion = other.transform.position;
        posistion.y = this.connection.position.y;
        posistion.x = this.connection.position.x;
        other.transform.position = posistion;

        Movement movement = other.GetComponent<Movement>();
        movement.SetDirection(direction);
    }
}
