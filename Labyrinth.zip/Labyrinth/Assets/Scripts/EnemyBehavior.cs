using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Enemy))]
public abstract class EnemyBehavior : MonoBehaviour
{
    public Enemy enemy { get; private set; }

    private void Awake()
    {
        this.enemy = GetComponent<Enemy>();
        this.enabled = false;
    }

    public virtual void Enable()
    {
        this.enabled = true;
    }

    public virtual void Disable()
    {
        this.enabled = false;
    }
}
