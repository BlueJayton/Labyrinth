using UnityEngine;

public class Charge : MonoBehaviour
{
    public bool isSpawned = true;

    private void Eat()
    {
        FindObjectOfType<GameManagerScript>().ChargePickedUp(this);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Minotaur"))
        {
            Eat();
        }
    }
}
