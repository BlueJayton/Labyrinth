using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyChase : EnemyBehavior
{
    public int duration = 10;

    private void OnEnable()
    {
        this.enemy.scatter.Disable();
    }
    private void OnDisable()
    {
        this.enemy.initialbehavior.Enable();
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        Node node = other.GetComponent<Node>();

        if (node != null && this.enabled && !this.enemy.frightened.enabled)
        {
            Vector2 direction = Vector2.zero;
            float minDistance = float.MaxValue;

            foreach (Vector2 availabledirection in node.directions)
            {
                Vector3 newPosition = this.transform.position + new Vector3(availabledirection.x, availabledirection.y, 0.0f);
                float distance = (this.enemy.target.position - newPosition).sqrMagnitude;

                if (distance < minDistance)
                {
                    direction = availabledirection;
                    minDistance = distance;
                }
            }

            this.enemy.movement.SetDirection(direction);
        }
    }
}
