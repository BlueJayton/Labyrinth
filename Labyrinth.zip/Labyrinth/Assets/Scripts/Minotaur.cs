using UnityEngine;

[RequireComponent(typeof(Movement))]
public class Minotaur : MonoBehaviour
{
    public Movement movement { get; private set; }
    public GameManagerScript logicscript;
    public Charge charge;
    public bool isCharging = false;
    public LayerMask wallLayer;
    public Lever lever;

    public void Awake()
    {
        this.movement = GetComponent<Movement>();
    }

    public void Start()
    {

    }

    public void Update()
    {

        if (this.isCharging)
        {
            this.movement.speedMultiplier = 2.0f;
            RaycastHit2D hit = Physics2D.BoxCast(this.transform.position, Vector2.one * .8f, 0.0f, this.movement.direction, .1f, this.wallLayer);
            if (hit.collider != null)
            {
                ResetCharge();
            }
        }
        else if (!this.isCharging)
        {
            this.movement.speedMultiplier = 1.0f;

            if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
            {
                MoveUp();
            }
            else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
            {
                MoveDown();
            }
            else if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))
            {
                MoveLeft();
            }
            else if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow))
            {
                MoveRight();
            }
            else if (Input.GetKeyDown(KeyCode.Space) && logicscript.numberOfChargesPickedUp > 0 && !isCharging)
            {
                ChargeUsed();
            }
        }
    }

    public void ChargeUsed()
    {
        logicscript.SetChargesPickedUp(this.logicscript.numberOfChargesPickedUp - 1);
        this.isCharging = true;
    }
    private void ResetCharge()
    {
        this.logicscript.ResetEnemyMultiplier();
        this.isCharging = false;
    }

    public void ResetState()
    {
        this.movement.ResetState();
        this.gameObject.SetActive(true);
    }

    public void MoveLeft()
    {
        this.movement.SetDirection(Vector2.left);
    }

    public void MoveRight()
    {
        this.movement.SetDirection(Vector2.right);
    }

    public void MoveUp()
    {
        this.movement.SetDirection(Vector2.up);
    }

    public void MoveDown()
    {
        this.movement.SetDirection(Vector2.down);
    }

    public void StopCharging()
    {
        this.isCharging = false;
    }

    public void Stun(float duration)
    {
        this.movement.Stun(duration);
    }
}
