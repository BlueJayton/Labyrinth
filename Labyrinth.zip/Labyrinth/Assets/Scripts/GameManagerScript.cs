using System.Collections;
using UnityEngine.UI;
using UnityEngine;

public class GameManagerScript : MonoBehaviour
{
    public Canvas StartMenuScreen;
    public Image MinotaurAnimation;
    public Image Title;
    public Image Bricks;
    public Button StartButton;


    public Canvas GameOverScreen;


    public Minotaur minotaur;
    private GameObject[] spawnedEnemies;

    public Man manPrefab;
    public Shield shieldPrefab;
    public Sword swordPrefab;
    public Theseus theseusPrefab;

    public Charge[] chargesSpawns;
    public int numberOfChargesPickedUp = 0;
    public int numberOfSpawnedCharges = 3;
    public int numberOfActiveCharges;
    public Transform[] gates;
    public GateSpawn[] gateSpawns;
    public Image charge1;
    public Image charge2;
    public Image charge3;

    public Lever lever;

    public int numberOfActiveEnemies;
    public int totalEnemiesSpawned;

    public Movement movement { get; private set; }

    public Text scoreDisplay;
    public int enemyMultiplier { get; private set; } = 1;
    public int score;
    public string scoreString;

    public int health;
    public Image heart1;
    public Image heart2;
    public Image heart3;

    public Text timeDisplay;
    public float elapsedTime;
    private string timeFormat = "{0:0}";
    public string timeString;
    public bool isTimerRunning = false;

    bool isSpawningCharges = false;

    private void Start()
    {
        Screen.orientation = ScreenOrientation.Portrait;
        this.minotaur.gameObject.SetActive(false);
    }

    public void StartButtonPressed()
    {
        Invoke(nameof(TurnOffStartScreen), 4f);
        Invoke(nameof(NewGame), 4f);
    }

    public void TurnOffStartScreen()
    {
        this.StartMenuScreen.gameObject.SetActive(false);
    }

    private void Update()
    {
        numberOfActiveCharges = numberOfChargesPickedUp + numberOfSpawnedCharges;
        if (numberOfActiveCharges < 3)
        {
            SpawnCharges();
        }

        if (isTimerRunning)
        {
            elapsedTime += Time.deltaTime;
            UpdateTimeDisplay();
        }
    }

    public void NewGame()
    {
        elapsedTime = 0f;
        isTimerRunning = true;
        spawnedEnemies = new GameObject[4];

        SetScore(0);
        SetHealth(3);
        SetChargesPickedUp(0);
        NewRound();

        // Set all charges to inactive
        for (int i = 0; i < chargesSpawns.Length; i++)
        {
            chargesSpawns[i].gameObject.SetActive(false);
            chargesSpawns[i].isSpawned = false;
        }

        // Spawn 3 charges at random positions
        SpawnInitialCharges();

        UpdateChargesDisplay();

        ResetMinotaur();

        SpawnMan(4);
    }

    private void NewRound()
    {
        ResetEnemyMultiplier();
        this.minotaur.ResetState();
    }

    private void SetScore(int score)
    {
        this.score = score;
    }

    private void SetHealth(int health)
    {
        this.health = health;
    }

    public void SetChargesPickedUp(int number)
    {
        this.numberOfChargesPickedUp = number;
        UpdateChargesDisplay();
    }

    public void IncreaseScore(int points)
    {
        this.score = this.score + (points * enemyMultiplier);
        this.enemyMultiplier++;
        this.numberOfActiveEnemies--;
        Invoke(nameof(SpawnEnemy), 15.0f);
    }

    public void MinotaurHit()
    {
        SetHealth(this.health - 1);
        this.minotaur.isCharging = false;
        this.minotaur.gameObject.SetActive(false);

        if (this.health == 0)
        {
            MinotaurKilled();
        } else
        {
            Invoke(nameof(ResetMinotaur), 3.0f);
        }

        if (this.health == 2)
        {
            heart3.enabled = false;
        }
        else if (this.health == 1)
        {
            heart2.enabled = false;
        }
        else if (this.health == 0)
        {
            heart1.enabled = false;
        }
    }

    public void MinotaurKilled()
    {
        GameOver();
    }

    public void ResetMinotaur()
    {
        minotaur.movement.ResetState();
        this.minotaur.gameObject.SetActive(true);
    }

    public void EnemyEscape()
    {
        GameOver();
    }

    public void ChargePickedUp(Charge charge)
    {
        charge.gameObject.SetActive(false);
        SetChargesPickedUp(this.numberOfChargesPickedUp + 1);
        numberOfSpawnedCharges--;
        charge.isSpawned = false;
    }

    public void ResetEnemyMultiplier()
    {
        this.enemyMultiplier = 1;
        UpdateScoreDisplay();
    }
    private void GameOver()
    {
        DeleteMen();
        isTimerRunning = false;
        this.minotaur.gameObject.SetActive(false);
        this.GameOverScreen.gameObject.SetActive(true);
    }
    public void Awake()
    {
        this.movement = GetComponent<Movement>();
    }

    public void SpawnCharges()
    {
        if (!isSpawningCharges && numberOfActiveCharges < 3)
        {
            StartCoroutine(SpawnCharge(10));
        }
    }

    private IEnumerator SpawnCharge(float waitTime)
    {
        isSpawningCharges = true;

        yield return new WaitForSeconds(waitTime);

        int index;
        do
        {
            index = Random.Range(0, chargesSpawns.Length);
        } while (chargesSpawns[index].isSpawned == true);

        chargesSpawns[index].gameObject.SetActive(true);
        chargesSpawns[index].isSpawned = true;
        numberOfSpawnedCharges++;

        isSpawningCharges = false;
    }

    private void SpawnInitialCharges()
    {
        for (int i = 0; i < numberOfSpawnedCharges; i++)
        {
            int index;
            do
            {
                index = Random.Range(0, chargesSpawns.Length);
            } while (chargesSpawns[index].isSpawned == true);

            chargesSpawns[index].gameObject.SetActive(true);
            chargesSpawns[index].isSpawned = true;
        }
    }
    private void UpdateTimeDisplay()
    {
        float minutes = Mathf.FloorToInt(elapsedTime / 60f);
        float seconds = Mathf.FloorToInt(elapsedTime % 60f * 10f) / 10f;
        timeString = string.Format(timeFormat, minutes.ToString("00") + ":" + seconds.ToString("00.0"));
        timeDisplay.text = timeString;
    }

    private void UpdateScoreDisplay()
    {
        scoreString = this.score.ToString();
        scoreDisplay.text = scoreString;
    }

    public void UpdateChargesDisplay()
    {
        if (this.numberOfChargesPickedUp == 0)
        {
            this.charge1.enabled = false;
            this.charge2.enabled = false;
            this.charge3.enabled = false;
        }
        else if (this.numberOfChargesPickedUp == 1)
        {
            this.charge1.enabled = true;
            this.charge2.enabled = false;
            this.charge3.enabled = false;
        }
        else if (this.numberOfChargesPickedUp == 2)
        {
            this.charge2.enabled = true;
            this.charge2.enabled = true;
            this.charge3.enabled = false;
        }
        else if (this.numberOfChargesPickedUp == 3)
        {
            this.charge1.enabled = true;
            this.charge2.enabled = true;
            this.charge3.enabled = true;
        }
    }

    public void SpawnEnemy()
    {
        if (totalEnemiesSpawned % 10 == 0)
        {
            SpawnTheseus(1);
        }
        else
        {
            int index = Random.Range(0, 3);

            if (index == 0)
            {
                SpawnMan(1);
            }
            else if (index == 1)
            {
                SpawnShield(1);
            }
            else if (index == 2)
            {
                SpawnSword(1);
            }
        }
    }

    public void SpawnMan(int number)
    {
        for (int i = 0; i < number; i++)
        {
            int index = Random.Range(0, gateSpawns.Length);
            float XPosition = gateSpawns[index].transform.position.x;
            float YPosition = gateSpawns[index].transform.position.y;

            Enemy enemy = Instantiate(manPrefab, new Vector3(XPosition, YPosition, 50), transform.rotation);
            enemy.gameObject.SetActive(false);
            enemy.spawnLocation = gateSpawns[index];
            enemy.movement.initialDirection = gateSpawns[index].initialDirection;
            enemy.initialtarget = this.lever.transform;
            enemy.target = enemy.initialtarget;
            enemy.lever = this.lever;
            enemy.frightened.Disable();
            enemy.chase.Disable();
            spawnedEnemies[numberOfActiveEnemies] = enemy.gameObject;
            this.numberOfActiveEnemies++;
            this.totalEnemiesSpawned++;

            StartCoroutine(EnableBehavior(enemy));
        }
    }

    public void SpawnShield(int number)
    {
        for (int i = 0; i < number; i++)
        {
            int index = Random.Range(0, gateSpawns.Length);
            float XPosition = gateSpawns[index].transform.position.x;
            float YPosition = gateSpawns[index].transform.position.y;

            Enemy enemy = Instantiate(shieldPrefab, new Vector3(XPosition, YPosition, 50), transform.rotation);
            enemy.gameObject.SetActive(false);
            enemy.spawnLocation = gateSpawns[index];
            enemy.movement.initialDirection = gateSpawns[index].initialDirection;
            enemy.initialtarget = this.lever.transform;
            enemy.target = enemy.initialtarget;
            enemy.lever = this.lever;
            spawnedEnemies[numberOfActiveEnemies] = enemy.gameObject;
            this.numberOfActiveEnemies++;
            this.totalEnemiesSpawned++;

            StartCoroutine(EnableBehavior(enemy));
        }
    }

    public void SpawnSword(int number)
    {
        for (int i = 0; i < number; i++)
        {
            int index = Random.Range(0, gateSpawns.Length);
            float XPosition = gateSpawns[index].transform.position.x;
            float YPosition = gateSpawns[index].transform.position.y;

            Enemy enemy = Instantiate(swordPrefab, new Vector3(XPosition, YPosition, 50), transform.rotation);
            enemy.gameObject.SetActive(false);
            enemy.spawnLocation = gateSpawns[index];
            enemy.movement.initialDirection = gateSpawns[index].initialDirection;
            enemy.initialtarget = this.lever.transform;
            enemy.target = enemy.initialtarget;
            enemy.lever = this.lever;
            spawnedEnemies[numberOfActiveEnemies] = enemy.gameObject;
            this.numberOfActiveEnemies++;
            this.totalEnemiesSpawned++;

            StartCoroutine(EnableBehavior(enemy));
        }
    }

    public void SpawnTheseus(int number)
    {
        for (int i = 0; i < number; i++)
        {
            int index = Random.Range(0, gateSpawns.Length);
            float XPosition = gateSpawns[index].transform.position.x;
            float YPosition = gateSpawns[index].transform.position.y;

            Enemy enemy = Instantiate(theseusPrefab, new Vector3(XPosition, YPosition, 50), transform.rotation);
            enemy.gameObject.SetActive(false);
            enemy.spawnLocation = gateSpawns[index];
            enemy.movement.initialDirection = gateSpawns[index].initialDirection;
            enemy.initialtarget = this.lever.transform;
            enemy.target = enemy.initialtarget;
            enemy.lever = this.lever;
            spawnedEnemies[numberOfActiveEnemies] = enemy.gameObject;
            this.numberOfActiveEnemies++;
            this.totalEnemiesSpawned++;

            StartCoroutine(EnableBehavior(enemy));
        }
    }

    private IEnumerator EnableBehavior(Enemy enemy)
    {
        yield return new WaitForSeconds(2f);
        enemy.initialbehavior.Enable();
        enemy.gameObject.SetActive(true);
    }

    public void DeleteMen()
    {
        for (int i = 0; i < 4; i++)
        {
            Destroy(spawnedEnemies[i]);
        }
        numberOfActiveEnemies = 0;
    }

    public void FlipLever()
    {
        if (this.lever.isOn == true)
        {
            Quaternion newRotation = Quaternion.Euler(0f, 0f, 0f);
            this.lever.transform.rotation = newRotation;
            this.lever.isOn = false;
        }
        else if (this.lever.isOn == false)
        {
            Quaternion newRotation = Quaternion.Euler(0f, 0f, 180f);
            this.lever.transform.rotation = newRotation;
            this.lever.isOn = true;
            Debug.Log("Lever turned on");
        }
    }
}
