using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Theseus : Enemy
{
    public override int points => 800;
    public override int difficultyrating => 5;

    public virtual void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.layer == LayerMask.NameToLayer("Minotaur"))
        {
            Vector2 toMinotaur = this.minotaur.transform.position - this.transform.position;
            if (Vector2.Dot(toMinotaur, this.movement.direction) < 0 && this.minotaur.isCharging)
            {
                EnemyHit();
            }
            else
            {
                FindObjectOfType<GameManagerScript>().MinotaurHit();
            }

        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (this.transform.position == this.spawnLocation.transform.position && this.lever.isOn == true)
        {
            FindObjectOfType<GameManagerScript>().EnemyEscape();
        }
    }

}
