using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lever : MonoBehaviour
{
    public bool isOn = false;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (this.isOn)
        {
            if (collision.gameObject.layer == LayerMask.NameToLayer("Minotaur"))
            {
                this.transform.Rotate(new Vector3(0, 0, 180));
                this.isOn = false;
            }
        }
        else if (!this.isOn)
        {
            if (collision.gameObject.layer == LayerMask.NameToLayer("Greeks"))
            {
                this.transform.Rotate(new Vector3(0, 0, 180));
                this.isOn = true;
            }
        }

    }
}
