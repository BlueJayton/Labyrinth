using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sword : Enemy
{
    public override int points => 600;
    public override int difficultyrating => 3;

    public virtual void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.layer == LayerMask.NameToLayer("Minotaur"))
        {
            if (this.minotaur.isCharging == false)
            {
                FindObjectOfType<GameManagerScript>().MinotaurHit();
            }
            else if (this.minotaur.isCharging == true)
            {
                EnemyHit();
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (this.transform.position == this.spawnLocation.transform.position && this.lever.isOn == true)
        {
            FindObjectOfType<GameManagerScript>().EnemyEscape();
        }
    }
}
