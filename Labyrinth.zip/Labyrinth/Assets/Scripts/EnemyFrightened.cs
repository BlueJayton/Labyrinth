using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyFrightened : EnemyBehavior
{
    public int duration = 10;

    public void OnEnable()
    {
        this.enemy.movement.direction = -this.enemy.movement.direction;
    }

    private void OnDisable()
    {
        this.enemy.initialbehavior.Enable();
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        Node node = other.GetComponent<Node>();

        if (node != null && this.enabled)
        {
            Vector2 direction = Vector2.zero;
            float maxDistance = 0;

            foreach (Vector2 availabledirection in node.directions)
            {
                Vector3 newPosition = this.transform.position + new Vector3(availabledirection.x, availabledirection.y, 0.0f);
                float distance = (this.enemy.target.position - newPosition).sqrMagnitude;

                if (distance > maxDistance)
                {
                    direction = availabledirection;
                    maxDistance = distance;
                }
            }

            this.enemy.movement.SetDirection(direction);
        }
    }
}
