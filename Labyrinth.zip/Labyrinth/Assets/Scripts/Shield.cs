using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shield : Enemy
{
    public override int points => 400;
    public override int difficultyrating => 2;

    public LayerMask minotaurLayer;

    public virtual void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.layer == LayerMask.NameToLayer("Minotaur"))
        {
            Vector2 toMinotaur = this.minotaur.transform.position - this.transform.position;
            if (Vector2.Dot(toMinotaur, this.movement.direction) < 0 && this.minotaur.isCharging)
            {
                EnemyHit();
            }
            else if (Vector2.Dot(toMinotaur, this.movement.direction) > 0 && this.minotaur.isCharging)
            {
                this.movement.direction = -this.movement.direction;                    
                this.minotaur.StopCharging();
                this.minotaur.Stun(5);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (this.transform.position == this.spawnLocation.transform.position && this.lever.isOn == true)
        {
            FindObjectOfType<GameManagerScript>().EnemyEscape();
        }
    }
}

