using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Man : Enemy
{
    public override int points => 200;
    public override int difficultyrating => 1;
    public virtual void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.layer == LayerMask.NameToLayer("Minotaur"))
        {
            if (this.minotaur.isCharging == true)
            {
                EnemyHit();
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (this.transform.position == this.spawnLocation.transform.position && this.lever.isOn == true)
        {
            FindObjectOfType<GameManagerScript>().EnemyEscape();
        }
    }
}
